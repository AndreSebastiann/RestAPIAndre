const user = {
    name: 'Deny Surya',
    address: 'Tabanan Bali'

}

module.exports = user;